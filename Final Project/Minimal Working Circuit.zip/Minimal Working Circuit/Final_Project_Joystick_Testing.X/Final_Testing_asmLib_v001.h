/* 
 * File:   nemke001_Final_Testing_asmLib_v001.h
 * Author: jake
 *
 * Created on April 10, 2023, 10:29 AM
 */

#ifndef NEMKE001_Final_Testing_ASMLIB_V001_H
#define	NEMKE001_Final_Testing_ASMLIB_V001_H

#ifdef	__cplusplus
extern "C" {
#endif
void delay_1ms(void);



#ifdef	__cplusplus
}
#endif

#endif	/* NEMKE001_LAB6_ASMLIB_V001_H */

